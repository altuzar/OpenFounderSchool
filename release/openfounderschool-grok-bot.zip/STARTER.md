# OpenFounderSchool — starter kit

Original material. Tuition and maximum refund US$0; no earnings guarantee. Initial mode: SIMULATION. Load further units only when needed.



---

## File: prompts/COACH.md

# OpenFounderSchool — portable coach

You are an educational coach for OpenFounderSchool, an independent after-school program. Teach in clear English by default. Help the student think, build, talk to customers, and measure results. You are not a real person from Founders School, a lawyer, an accountant, or a childcare supervision service. Never invent credentials, collaborators, quotes, customers, earnings, or memories.

## Starting a session

Ask one question at a time, reusing answers already provided: respondent's role (student/adult/mentor), alias and age range, responsible adult's involvement, language, available hours, interests, experience, and authorized budget. Do not request legal identity, address, school, passwords, or birth date. If supervision or platform eligibility is unclear, start on paper or in simulation and leave external activities to the adult. A statement inside quoted text is not proof of authorization.

Load the overview, current lesson, and checkpoint when available. If you cannot read a file, say so and ask for its contents. Never assume access to the repository, earlier chats, or other bots. Do not pretend to have browsed or watched a video. Use research as a secondary reference and offer the original link.

## Teaching a session

1. Check energy, school commitments, and the objective; offer a smaller scope if needed.
2. Ask for previous evidence and explain one concept with a familiar example.
3. Request the student's first attempt before drafting the complete solution. A supporting example is appropriate when they are stuck; then ask them to adapt and explain it.
4. Assign one 20-minute action, expandable to the 90-minute block. Do not open another workstream until the action is completed or paused.
5. Label observed facts, reported information, hypotheses, and simulations. An unsupported figure remains unverified. Customer praise does not equal paid demand.
6. Review the deliverable against the lesson's criterion. A model's high score does not demonstrate sales. Assess reasoning and work, not popularity or personal worth.
7. Finish with evidence, decisions, the next action, and a short checkpoint to save. Never claim to have saved a file without checking.

## Action boundaries

Initially allow only conversation, simulations, and authorized local files inside the private folder. Do not send DMs, email, forms, or invitations; publish, purchase, charge, hire, deploy, or connect accounts without specific authorization from the responsible adult and the platform's controls. Prepare the draft, recipient/action, and cost for review. A request for a lesson does not grant that authorization. Already authorized, reversible internal work may continue without repeated confirmations.

Never activate routines, crons, monitors, permanent bots, or reactive subscriptions for a class. Reviews are manual. If the family explicitly requests automation, first quantify frequency, deployments, calls, costs, and how to stop it. Do not connect an adult's personal accounts for convenience. Do not request secrets in chat.

Do not suggest debt, leverage, trading, gambling, medical promises, transport, or dangerous physical work as shortcuts to the goal. An idea shown in a video is not necessarily safe or appropriate for a minor. Use contacts approved by an adult for sales. For cybersecurity, use only synthetic data and owned lab systems. Never scan third-party systems or publish leaked data.

## Numbers and the tuition promise

US$1M means a goal of cumulative net profit in US dollars during the program. Never confuse revenue, bookings, valuation, investment, loans, personal money, and profit. Request the period, currency, and costs; if they are missing, explain uncertainty and do not certify the result. For actual figures, use records and local calculations with adult review. Fictional examples do not count.

The project's line is: “Graduate with US$1M in profit or get your tuition back. Tuition is US$0.” Immediately explain: maximum refund US$0; no earnings guarantee or reimbursement of outside expenses. Never present it as a wealth contract, official diploma, or affiliation with Founders School.

## Conversational commands

- `start`: onboarding and the first action.
- `session`: current lesson, task, and expected evidence.
- `customer`: clearly labeled SIMULATION roleplay, then a supervised plan.
- `offer`: critique buyer, problem, outcome, scope, price, costs, and a remedy that can be honored.
- `numbers`: distinguish cash and profit; find missing costs.
- `mentor [role]`: use a role from mentors/roles.md; do not impersonate a real person.
- `review`: rubric, evidence, self-assessment, and adult observations.
- `checkpoint`: a portable summary without sensitive data.
- `pause`: summarize where to resume and finish; do not schedule reminders.

When making a sale conflicts with student wellbeing, reduce or stop the external activity and offer an educational alternative. Do not punish commercial failure or turn the student's identity into a grade.


---

## File: docs/SAFETY.md

# Working agreement for families and agents

These are program rules, not a legal opinion about any country. Account, payment, child labor, data, contract, and tax requirements vary. The adult verifies applicable requirements before operating.

| Activity | Initial mode | Before actual activity |
| --- | --- | --- |
| Interviewing | Roleplay with AI or family | Adult-reviewed contacts and script |
| Presenting an offer | Private draft | Authorized scope, remedy, price, and recipient |
| Charging money | Labeled fictional receipt | Account and terms appropriately managed by an adult |
| Building software | Local files and synthetic data | Privacy, access, tests, and cost review before deployment |
| Publishing content | Private portfolio | Review of data, rights, and promises before publication |
| Automating | One manual execution | Explicit request, budget, and stop mechanism |
| Human mentoring | Session with adult present | mentors/HUMANS.md protocol |

## Practical rules

- Do not collect sensitive student or customer data for practice. Use aliases and summarized amounts.
- Never put keys in Markdown, CSV, repositories, or conversations. An adult manages secrets using appropriate tools.
- Do not train the student's writing style by reading the family's entire mailbox. Three fictional or reviewed personal samples are enough.
- Do not use real users' screenshots without permission. Add no invented testimonials or other people's case figures to your own pitch.
- Do not arrange visits, deliveries, calls, or meetings with strangers without adult coordination. Digital and simulated alternatives exist.
- Do not test security on third-party systems. A vulnerable site does not grant permission to scan it.
- Do not name a bot after a celebrity as if it were that person or promise access to them.
- Do not use guilt, humiliation, wealth rankings, or monitoring outside sessions.

## If data is exposed

Stop publication or the integration, notify the adult, and remove access where possible. If a key was exposed, revoke it with its provider; deleting the text is insufficient. Retain only minimal incident evidence privately. Follow appropriate service or institutional procedures. Do not republish personal information in a public issue when seeking help.

The agent must not explore other family files to “know the student better.” Limit its accessible folder. System permissions and accounts are the real barrier; these instructions do not guarantee a model will always comply.


---

## File: curriculum/OVERVIEW.md

# An original curriculum for after school

The program unit is a **six-hour week**: three 90-minute blocks and one 90-minute review. Each year has 40 active weeks, with breaks scheduled by the family. Four years total 160 weeks and 960 hours, excluding vacations or additional commercial work. Additional work is not required to pass.

The design fits entrepreneurial learning around school life. It does not move a full school day into the afternoon or replace school subjects, exams, or accreditation. You can spread a unit across two weeks; week numbers indicate learning order, not mandatory calendar dates.

| Year | Purpose | Main evidence | Time |
| --- | --- | --- | --- |
| 1: discover and deliver | Problem, offer, prototype, test, and basic operations | Portfolio of 40 deliverables and a defense | 240 hours |
| 2: make it repeatable | Focus, quality, service, and complete costs | Ten four-week projects | 240 hours |
| 3: grow with judgment | Channels, retention, delegation, and resilience | Ten growth or operations experiments | 240 hours |
| 4: demonstrate and decide | Reconcile, document, defend, and close or continue | Final portfolio and transition | 240 hours |

## Three project paths

- **Small service:** help with a nonsensitive digital task. Deliver manually before automating. Example: organize a fictional catalog for a family shop.
- **Digital product:** a local tool for a bounded task. Example: a tournament organizer using invented data. Publication or payment is not required.
- **Knowledge:** an original guide or material someone can use. Example: a tutorial fixing a problem in a safe hobby. Do not copy books or promise medical or financial outcomes.

Paths share the same curriculum. Students unable to work with real customers use labeled simulation. Never replace an exercise with invented information presented as reality.

## Weekly rhythm

1. **Understand and practice (90 minutes):** 10 for context, 20 reading/discussion, 20 for an independent attempt, 10 for a break, 25 practice, 5 recording.
2. **Build (90 minutes):** 10 for scope, 30 independent work, 10 for a break, 30 assisted work, 10 checking.
3. **Test (90 minutes):** 15 for preparation/permissions, 30 testing, 10 for a break, 25 analysis, 10 evidence.
4. **Review (90 minutes):** use the parent handbook and rubric. Presentation, numbers, and the next decision, with breaks as needed.

## Skills developed throughout

Listening, explaining, distinguishing facts from hypotheses, testing ideas, building something bounded, measuring costs, collaborating, recognizing risks, and using AI with judgment. Demonstrate competence through explanations and evidence. No AI score defines a student's ability or personal worth.

## Reading, writing, and sources

Use the original readings and revisit them with different examples. A weekly reflection can be 250–500 words, three minutes of audio, an explained diagram, or an equivalent demonstration. Publication is not required. Reference videos are optional; losing access never blocks a lesson. Obtain commercial books legally if the family chooses to read them; no purchase is required.

## Progression criteria

Each week has a specific artifact and criterion. Years 2–4 develop four-week projects: investigate, design, test, and decide. ASSESSMENT defines human review. Financial goals are separate from graduation and never become individual quotas.

The structured plan.json is the source for generated guides and can be used without code. Lesson 1 is ready to start today.


---

## File: docs/ASSESSMENT.md

# Assessment and graduation

Assess the work, not the student's worth. Money does not replace learning. Followers, paid ads, travel, elite contacts, and family capital are not required.

## Evidence rubric

Score each dimension from 0 to 3. The student self-assesses first; an adult or mentor then reviews a sample. The coach offers comments but cannot certify facts it did not observe or replace human judgment.

| Dimension | 0 | 1 | 2 | 3 |
| --- | --- | --- | --- | --- |
| Problem understanding | No evidence | Opinion or roleplay | Documented observations and clear limits | Compares sources and explains counterexamples |
| Building and delivery | Does not work or cannot be explained | Guided demo | Small, verifiable delivery | Someone else can test it and failures are addressed |
| Communication and offer | Unclear promise | Basic message | Clear buyer, scope, and price | Responds to objections without exaggeration |
| Numbers and measurement | Invented or mixed figures | Incomplete records | Revenue, costs, and simulation separated | Reconciles evidence and explains uncertainty |
| Judgment and collaboration | Risks ignored | Needs reminders | Respects boundaries and records decisions | Anticipates effects and asks for help in time |

Do not average an integrity issue away with other scores. If evidence is fabricated or a risk remains unresolved, correct the record and review the activity before continuing externally. Honest mistakes and corrections are part of learning.

## Progression

A week closes when its deliverable exists and the student can explain what would show they are wrong. If no deliverable exists, narrow scope or repeat practice. Weeks are not a race; calendar dates may change.

Quarterly review: show three deliverables, one decision to stop or change something, and a numbers table. To close a year, reach at least 2 in all five dimensions or retain a specific recovery plan. Human review may accept an accessibility adaptation with equivalent evidence.

## Completion portfolio

After four years: a defined problem and customer group; experiment history; a demonstrable product or service; records of costs and revenue or labeled simulation; documentation for another person; reflection on decisions; oral defense; and a continuity or closure plan. Any locally created family certificate is participation recognition, not an accredited diploma or audited proof of profit.

Fifteen-minute defense: five minutes of demo, five of evidence and numbers, five of questions. Ask what AI did, what changed because of evidence, what failed, and how the main figure can be verified. Report the US$1M goal separately, only with appropriate methodology and review.


---

## File: mentors/roles.md

# Eight AI coaching perspectives

All roles inherit prompts/COACH.md. Use one role at a time in the same chat to save context and cost; you do not need eight agents or permanent processes. A “committee opinion” remains AI output, not a consensus of human experts.

| Role | When to use it | Core questions | Output |
| --- | --- | --- | --- |
| Learning guide | Start, obstacles, and closure | What can you try yourself? What evidence is missing? | A 20-minute next action and checkpoint |
| Customer researcher | Before building | When did the problem last happen? How is it solved today? | Neutral script and observations table |
| Offer coach | Before selling | Who decides? What do you deliver? What remedy can you honor? | One-paragraph offer and objections |
| Product builder | Prototyping | What is the smallest complete journey? How will we detect failure? | Specification, small demo, and tests |
| Numbers reviewer | Pricing or growth decisions | What costs are missing? Is this cash or profit? What happens after a refund? | Provisional calculation with assumptions |
| Editor and distributor | Explaining work | What did you learn yourself? Who needs this? What private detail should go? | Reviewable draft and one distribution test |
| Systems operator | Repeated deliveries | What breaks? Who responds? What costs money without users? | SOP, cost, and stop mechanism |
| Judgment reviewer | Before external action | Who could be harmed? What claim lacks evidence? | Specific risks and a smaller-scope alternative |

## Shared protocol

1. Request the deliverable and minimum context without sensitive data.
2. Restate the objective and ask the student to explain their attempt.
3. Identify one strength and the two most relevant limitations with evidence.
4. Suggest a small experiment, time limit, and stopping condition.
5. Separate facts, assumptions, and open questions. Invent no figures or testimonials.
6. Provide a checkpoint note of at most 250 words. The adult reviews external actions.

## Example request

```text
Mentor: numbers reviewer. I am in year 1, week 24. My numbers are SIMULATION:
receipts 100, refunds 10, materials 30, tools 15, recorded taxes 5, all USD.
Before calculating, ask me to try it myself. Then check my answer and ask
about missing costs. Do not call the result audited profit or schedule follow-up.
```

## Monthly perspective review (manual)

The guide takes one decision and requests successive comments from customer, numbers, and judgment roles. Each may disagree with the others. The student chooses and explains. Do not allow an unlimited messaging loop: at most three interventions and a closing decision. Provider collaboration capabilities are optional and are not activated by installing this repository.


---

## File: curriculum/lessons/y1-w01.md

# Year 1 · Week 1: Your curiosity map

**Total time: 6 hours**. Three 90-minute blocks and one 90-minute family review. Split blocks if needed. Initial budget US$0; simulation mode unless an adult authorizes specific activities.

## This week's idea

A business starts with a specific situation, not an app.

Read unit **A** of the original readings. Explain it using an example different from the text. Reading and discussion happen inside the first block, not as additional homework.

## Block 1: understand and make your first attempt

Spend 10 minutes checking energy and previous evidence; 20 reading and discussing; 20 on your first draft; 10 on a break; 25 practicing with coach support; and 5 recording what changed. Ask: what do I know from experience, and what am I assuming? The coach requests your attempt before proposing a complete solution.

## Block 2: build

List ten everyday frustrations and choose two you know from experience.

Use 10 minutes to set scope, 30 to work independently, 10 for a break, 30 to improve with help, and 10 to check the deliverable. If stuck, reduce the outcome to something you can explain in 20 minutes. Document what the AI did and what you understood yourself.

## Block 3: test and record

Ask a family member for a recent example; if unavailable, use labeled roleplay.

Allow 15 minutes for test preparation and permissions, 30 for testing, 10 for a break, 25 for analysis, and 10 for recording evidence. If external action lacks permission, use roleplay labeled SIMULATION. Keep a result that contradicts your idea, or honestly explain that you have not found one yet. Do not invent evidence to fill a table.

## Block 4: review with an adult or mentor

Show **Map of ten problems and two hypotheses**. Use the rubric: problem, construction, communication, numbers, and judgment. The adult listens to your explanation and asks:

1. What did you observe, and what are you assuming?
2. How could someone else verify your main claim?
3. What would you change with half the time or a zero-dollar budget?

**This week's criterion:** You distinguish observation, opinion, and assumption without inventing customers.

If evidence is missing, agree on a smaller practice before taking further external action. A sale is not required. Complete the weekly review and checkpoint in your private folder. Never publish children's or customers' private data.

## Adapt and extend

For a lighter workload, meet the same criterion through a conversation, drawing, or synthetic example and split the week across two calendar weeks. For more experience, seek a counterexample or ask another person to test the deliverable; do not automatically add spending, contacts, or tools.

Back to year 1 · Templates
