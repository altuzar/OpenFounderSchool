"""Render original curricular data into human-readable guides (offline)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def render():
    data = json.loads((ROOT / 'curriculum/plan.json').read_text(encoding='utf-8'))
    for year in range(1, 5):
        weeks = [e for e in data['entries'] if e['year'] == year]
        parts = [f'# Año {year} — guía semanal', '',
                 '40 semanas activas × 6 horas = 240 horas. Ajusta fechas, descansos y accesibilidad con tu familia.', '',
                 'Material original de OpenFounderSchool. Las simulaciones nunca cuentan como clientes o utilidad real.', '',
                 'Lee [el overview](../OVERVIEW.md) y [la rúbrica](../../docs/ASSESSMENT.md).', '']
        for e in weeks:
            w = e['week']
            parts += [f'## Semana {w}: {e["title"]}', '', e['concept'], '',
                      f'- **Construir:** {e["build"]}', f'- **Probar:** {e["test"]}',
                      f'- **Entregar:** {e["artifact"]}', f'- **Criterio:** {e["criterion"]}', '']
            if year == 1:
                parts += [f'[Abrir la lección completa](../lessons/y1-w{w:02d}.md).', '']
                reading = ['A','A','A','A','C','D','C','B','B','H',
                           'E','E','E','E','E','B','C','C','E','H',
                           'B','F','B','D','B','B','H','F','E','H',
                           'G','G','C','D','F','H','D','E','H','H'][w - 1]
                text = f'''# Año 1 · Semana {w}: {e['title']}

**Tiempo total: 6 horas**. Tres bloques de 90 minutos y una revisión familiar de 90. Divide cada bloque si lo necesitas. Presupuesto inicial US$0; modo simulación salvo actividades concretas autorizadas por el adulto.

## Idea de esta semana

{e['concept']}

Lee la unidad **{reading}** de [lecturas originales](../READINGS.md). Explícala con un ejemplo distinto al texto. La lectura y la conversación ocurren dentro del primer bloque, no son tarea adicional.

## Bloque 1: comprender y hacer tu primer intento

10 min para revisar energía y evidencia anterior; 20 para leer y discutir; 20 para tu primer borrador; 10 de pausa; 25 para practicar con apoyo del coach y 5 para anotar qué cambió. Pregunta: ¿qué sé por experiencia y qué estoy suponiendo? El coach pide tu intento antes de proponer una solución completa.

## Bloque 2: construir

{e['build']}

Usa 10 min para elegir alcance, 30 para trabajar tú, 10 de pausa, 30 para mejorar con ayuda y 10 para comprobar el entregable. Si te bloqueas, reduce el resultado a una versión que puedas explicar en 20 minutos. Documenta qué hizo la IA y qué comprendiste tú.

## Bloque 3: probar y registrar

{e['test']}

Dedica 15 min a preparar prueba y permisos, 30 a probar, 10 a pausar, 25 a analizar y 10 a registrar. Si requiere acciones externas sin permiso, usa roleplay etiquetado SIMULACIÓN. Guarda un resultado que contradiga tu idea o explica honestamente que todavía no lo encontraste. No inventes evidencia para completar la tabla.

## Bloque 4: revisión con adulto o mentor

Muestra **{e['artifact'].rstrip('.')}**. Revisa la [rúbrica](../../docs/ASSESSMENT.md): problema, construcción, comunicación, números y criterio. El adulto escucha tu explicación y hace estas preguntas:

1. ¿Qué parte observaste y qué parte supones?
2. ¿Cómo podría comprobar otra persona tu afirmación principal?
3. ¿Qué cambiarías si tuvieras la mitad del tiempo o presupuesto cero?

**Criterio de esta semana:** {e['criterion']}

Si falta evidencia, acuerden una práctica más pequeña antes de avanzar externamente. No se exige una venta. Completa [la revisión semanal](../../templates/weekly-review.md) y [el checkpoint](../../templates/checkpoint.md) en tu carpeta privada. Nunca publiques datos de menores ni de clientes.

## Adaptación y ampliación

Para menor carga: cumple el mismo criterio con una conversación, dibujo o ejemplo sintético y reparte la semana en dos. Para más experiencia: busca un contraejemplo o pide que otra persona pruebe el entregable; no añadas gastos, contactos ni herramientas automáticamente.

[Volver al año 1](../years/year-1.md) · [Plantillas](../../templates/README.md)
'''
                (ROOT / f'curriculum/lessons/y1-w{w:02d}.md').write_text(text, encoding='utf-8')
        if year > 1:
            parts += ['## Cómo ejecutar cada semana', '',
                      'Bloque 1: revisa evidencia y explica el concepto (90 min). Bloque 2: construye la entrega indicada (90 min). '
                      'Bloque 3: ejecuta la prueba propuesta con límites y permisos (90 min). Bloque 4: autoevalúa, revisa con adulto y guarda checkpoint (90 min). '
                      'Cada ciclo de cuatro semanas produce una decisión, no una cuota obligatoria de ingresos. '
                      'Vuelve a las lecturas y plantillas según la necesidad; el coach puede explicar y adaptar, sin inventar evidencia.', '']
        (ROOT / f'curriculum/years/year-{year}.md').write_text('\n'.join(parts), encoding='utf-8')


if __name__ == '__main__':
    render()
